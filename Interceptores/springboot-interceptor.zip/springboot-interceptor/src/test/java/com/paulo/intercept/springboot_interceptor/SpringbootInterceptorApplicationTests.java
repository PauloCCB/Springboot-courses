package com.paulo.intercept.springboot_interceptor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootInterceptorApplicationTests {

	@Test
	void contextLoads() {
	}

}
